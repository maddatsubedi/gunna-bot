const arr = [
    'Be Respectful\n' +
    'Treat everyone with kindness. No harassment, hate speech, or bullying.\n' +
    '  \n' +
    'Keep It Clean\n' +
    'This is an all-ages server. No explicit or inappropriate content.',
    'Stay On-Topic\n' +
    'Use the correct channels for discussions.\n' +
    ' \n' +
    'No Spam\n' +
    'Avoid spamming messages, emojis, or excessive caps.',
    'No Self-Promotion\n' +
    'Promoting yourself, your server, or links is not allowed unless permitted by staff.',
    'Protect Privacy\nDon’t share personal info—yours or others’.',
    'No Impersonation\n' +
    'Don’t pretend to be someone else, including mods or public figures.',
    'Follow Discord’s Guidelines\n' +
    'Stick to Discord’s Terms of Service and Community Guidelines.',
    'No Toxic Behavior\n' +
    'Avoid drama, trolling, or anything that creates a negative environment.\n' +
    ' \n' +
    'Listen to Mods\n' +
    'Follow the instructions of moderators and admins at all times.'
]

// console.log(arr.length);